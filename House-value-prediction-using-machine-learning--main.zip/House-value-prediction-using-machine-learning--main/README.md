# House-value-prediction-using-machine-learning-
This project is about creating a machine learning model that can predict the house value based on the given dataset. The dataset used to train the model is the California housing dataset from sci-kit learn and it can be uploaded directly from the sci-kit learn dataset in a jupyter notebook. We use different machine learning algorithms such as linear regression, decision tree and random forest to train the model, and the model that gives the best performance is used to predict the house value for new data. 

For the full video explanation of the topic, you can check out my video by clicking on the following link :>> https://youtu.be/ODWKHj85OLA
